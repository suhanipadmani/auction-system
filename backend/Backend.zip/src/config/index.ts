﻿export { env } from "./env";
